<div class="theme_page_container white_bg h-100 w-100">
		<iframe src="theme-folder/theme_index.html" class="page_frame h-100" id="theme_page_container"></iframe>
</div>
